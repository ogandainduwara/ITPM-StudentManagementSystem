<?php

if (isset($_POST['create'])) {
    include "../db_conn.php";
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $fname = validate($_POST['fname']);
    $stid = validate($_POST['stid']);
    $phone = validate($_POST['phone']);
    $acyear = validate($_POST['acyear']);
    $program = validate($_POST['program']);
    //$delichar=validate($_POST['delichar']);

    $user_data = 'fname=' . $fname . '&sid=' . $sid . '&phone=' . $phone . '&acyear' . $acyear. '&program' . $program;

    if (empty($fname)) {
        header('Location:../index.php?error=Full Name  is  required&$user_data');
    } elseif (empty($stid)) {
        header('Location:../index.php?error=Student ID is  required&$user_data');
    } elseif (empty($phone)) {
        header('Location:../index.php?error=Phone Number is  required&$user_data');
    } elseif (empty($acyear)) {
        header('Location:../index.php?error=Acadamic year is  required&$user_data');

    } elseif (empty($program)) {
        header('Location:../index.php?error=Programme  required&$user_data');
    } else {

        $sql = " INSERT INTO  LiberaryMember(fname,stid,phone,acyear,program) VALUES('$fname','$stid','$phone','$acyear','$program')";

        $result = mysqli_query($conn, $sql);
        if ($result) {

            header('Location:../read.php?success=successfully create');
        } else {

            header('Location:../index.php?error=unknown error occurred&$user_data');
        }
    }
}
