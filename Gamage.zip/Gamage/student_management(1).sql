-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2022 at 02:22 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigment`
--

CREATE TABLE `assigment` (
  `id` int(11) NOT NULL,
  `aname` varchar(200) CHARACTER SET utf8 NOT NULL,
  `dp` varchar(200) CHARACTER SET ucs2 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assigment`
--

INSERT INTO `assigment` (`id`, `aname`, `dp`) VALUES
(17, '', '11482204141649936117.png'),
(19, 'TESTgiugi', '53882204151650012375.docx'),
(21, 'nvd', '56922204171650191603.docx');

-- --------------------------------------------------------

--
-- Table structure for table `carpark`
--

CREATE TABLE `carpark` (
  `id` int(11) NOT NULL,
  `stuid` varchar(200) NOT NULL,
  `aname` varchar(200) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `vtype` varchar(200) NOT NULL,
  `payment` float NOT NULL,
  `dp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carpark`
--

INSERT INTO `carpark` (`id`, `stuid`, `aname`, `fname`, `vtype`, `payment`, `dp`) VALUES
(1, '5665', 'gkrg', 'hvhjv', 'Bike', 0, '4802204161650086967.docx'),
(2, '5665', 'gkrg', 'hvhjv', 'Bike', 65165, '36772204161650087003.png'),
(3, '44', 'igiu', 'lklkn', 'Other', 1500, '47762204161650087832.png'),
(4, '44', 'igiu', 'lklkn', 'Car', 2000, '30082204161650087856.png'),
(5, 'rgrg4546', 'u567u', 'erhe', 'Bike', 1000, '71202204161650129248.docx'),
(6, 'hio', 'hjpoj', 'hpoj', 'Bike', 1000, '94932204161650129499.docx'),
(7, 'guig', 'llgjg', 'gjh;', 'Car', 2000, '19332204171650186315.png'),
(8, 'knckld', ';llgjfl', 'znvsd', 'Bike', 1000, '77212204171650192867.docx');

-- --------------------------------------------------------

--
-- Table structure for table `liberarymember`
--

CREATE TABLE `liberarymember` (
  `id` int(11) NOT NULL,
  `fname` varchar(200) CHARACTER SET ucs2 NOT NULL,
  `stid` varchar(10) CHARACTER SET ucs2 NOT NULL,
  `phone` int(10) NOT NULL,
  `acyear` varchar(100) NOT NULL,
  `program` varchar(200) CHARACTER SET ucs2 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `liberarymember`
--

INSERT INTO `liberarymember` (`id`, `fname`, `stid`, `phone`, `acyear`, `program`) VALUES
(9, 'ghd', 'lkfngklfd', 165, '2022-04-06', 'hlg'),
(10, 'sddfh', 'lkfdj', 0, '0000-00-00', 'kvv'),
(11, 'sddfh', 'lkfdj', 0, '2021', 'kvv'),
(12, 'sddfh', 'lkfdj', 26468, '2022', 'kvv');

-- --------------------------------------------------------

--
-- Table structure for table `studentregister`
--

CREATE TABLE `studentregister` (
  `id` int(11) NOT NULL,
  `sname` varchar(200) CHARACTER SET ucs2 NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) CHARACTER SET ucs2 NOT NULL,
  `smail` varchar(100) CHARACTER SET ucs2 NOT NULL,
  `saddress` varchar(100) CHARACTER SET ucs2 NOT NULL,
  `sschool` varchar(200) CHARACTER SET ucs2 NOT NULL,
  `ftype` varchar(100) CHARACTER SET ucs2 NOT NULL,
  `ctype` varchar(100) CHARACTER SET ucs2 NOT NULL,
  `phone` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentregister`
--

INSERT INTO `studentregister` (`id`, `sname`, `dob`, `gender`, `smail`, `saddress`, `sschool`, `ftype`, `ctype`, `phone`) VALUES
(31, 'sdfdsfasdas', '2022-04-05', 'Male', 'asdadasd@hjl', 'asdsadasasdsa', 'asdasd', 'IT', 'Car', 702900565),
(32, 'jbh', '2022-04-04', 'Male', 'khil@gmail.com', 'iho', 'gio', 'BM', 'Bike', 564646);

-- --------------------------------------------------------

--
-- Table structure for table `univarsity`
--

CREATE TABLE `univarsity` (
  `id` int(11) NOT NULL,
  `yname` varchar(200) CHARACTER SET ucs2 NOT NULL,
  `yfaculty` varchar(200) CHARACTER SET ucs2 NOT NULL,
  `ycourse` varchar(200) CHARACTER SET ucs2 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `FullName` varchar(200) NOT NULL,
  `Student_Number` varchar(200) NOT NULL,
  `year` varchar(100) NOT NULL,
  `Gender` varchar(200) NOT NULL,
  `Password1` varchar(100) NOT NULL,
  `Password2` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assigment`
--
ALTER TABLE `assigment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carpark`
--
ALTER TABLE `carpark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `liberarymember`
--
ALTER TABLE `liberarymember`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studentregister`
--
ALTER TABLE `studentregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `univarsity`
--
ALTER TABLE `univarsity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assigment`
--
ALTER TABLE `assigment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `carpark`
--
ALTER TABLE `carpark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `liberarymember`
--
ALTER TABLE `liberarymember`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `studentregister`
--
ALTER TABLE `studentregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `univarsity`
--
ALTER TABLE `univarsity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
